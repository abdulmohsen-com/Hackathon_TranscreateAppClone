package com.example.transcrate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.qadam.MapsActivity;


public class contact extends AppCompatActivity {
    private static final int REQUEST_CALL = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_contact);
        Button Submit = findViewById(R.id.button);
        final EditText email = findViewById(R.id.editTextTextEmailAddress);
        final EditText name = findViewById(R.id.editTextTextPersonName);
        final EditText phonetext = findViewById(R.id.editTextPhone);

        ImageButton phone = findViewById(R.id.Phone);
        ImageButton map = findViewById(R.id.map);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email.setText("");
                name.setText("");
                phonetext.setText("");
            }
        });

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone = "+9651804949";
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            }
        });

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(contact.this , MapsActivity.class);
                startActivity(intent);
            }
        });

    }
}